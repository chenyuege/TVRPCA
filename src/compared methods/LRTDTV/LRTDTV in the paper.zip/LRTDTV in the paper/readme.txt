1: code explanation
   LRTDTV.m    is code for LRTDTV approximate model
   LRTDTV_w.m  is code for weight sstv LRTDTV approximate model
   LRTDTV_G.m  is code for general LRTDTV model
   LRTDTV_Gw.m is code for weight sstv general LRTDTV model
2: simulation-case(1-6)_demo.m 
    this demo is example of simulation case1-case6 in the paper.
        <Hyperspectral Image Restoration via Total Variation 
                           Regularized Low-rank Tensor Decomposition>